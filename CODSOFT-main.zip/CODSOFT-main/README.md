# CODSOFT
In this repository, I would be sharing all of my projects which include(a portfolio, landing page, and a Calculator) made through my skills in HTML and CSS during my summer internship at @ Codsoft
